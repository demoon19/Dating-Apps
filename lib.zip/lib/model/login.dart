class LoginResponse {
  final int id;
  final String username;

  LoginResponse({required this.id, required this.username});
}
